using System;
using System.Xml;

namespace DTBOOK2UrakawaInstance
{
  /// <summary>
  /// Event argument for progress events
  /// </summary>
  public class ProgressEventArgs : EventArgs
  {
    /// <summary>
    /// A <see cref="bool"/> indicating if the progress was cancelled during the event call
    /// </summary>
    /// <remarks>If one wants to cancel the process monitored by the event, 
    /// <see cref="Cancel"/> should be set to <c>true</c></remarks>
    public bool Cancel;

    /// <summary>
    /// The progress message 
    /// </summary>
    public string Message;

    /// <summary>
    /// Default constructor 
    /// </summary>
    public ProgressEventArgs(string msg) : base()
    {
      Message = msg;
      Cancel = false;
    }
  }

  /// <summary>
  /// Delegate for progress events
  /// </summary>
  public delegate void XmlInstanceGeneratorProgressEventDelegate(XmlInstanceGenerator o, ProgressEventArgs e);

	/// <summary>
	/// Provides functionality for generating an Urakawa instance xml document based on a Z39.86 DTB.
	/// </summary>
	/// <remarks>
	/// Currently only full text Z39.86 DTBs are supported
	/// </remarks>
	public class XmlInstanceGenerator
	{
    /// <summary>
    /// Event fired while generating the instance document, showing the progress of the generation
    /// </summary>
    public event XmlInstanceGeneratorProgressEventDelegate Progress;

    private bool FireProgress(string Message)
    {
      ProgressEventArgs e = new ProgressEventArgs(Message);
      if (Progress!=null) Progress(this, e);
      return e.Cancel;
    }

    /// <summary>
    /// The path of the XSLT doing the dtbook2InstanceXml transform
    /// </summary>
    public static string XSLT_PATH = System.IO.Path.Combine(
      System.IO.Path.GetDirectoryName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName),
      "dtbook2Instance.xsl");

    private string mDTBOOKPath;

    /// <summary>
    /// The path of the dtbook file of the DTB
    /// </summary>
    public string DTBOOKPath
    {
      get
      {
        return mDTBOOKPath;
      }
    }

    /// <summary>
    /// Public constructor creating a generator based on a single DTBOOK file
    /// </summary>
    /// <param name="dtbook">The path of the DTBOOK file</param>
		public XmlInstanceGenerator(string dtbook)
		{
      mDTBOOKPath = dtbook;
		}

    private static XmlElement[] XmlNodeListToXmlElementArray(XmlNodeList nodes)
    {
      XmlElement[] res = new XmlElement[nodes.Count];
      for (int i=0; i<nodes.Count; i++)
      {
        res[i] = (XmlElement)nodes[i];
      }
      return res;
    }

    /// <summary>
    /// Processes <c>Node</c>s with nested smilref attributes in instance document
    /// </summary>
    /// <param name="instanceDoc">The instance <see cref="XmlDocument"/></param>
    public void ProcessNestedSmilrefNodes(XmlDocument instanceDoc)
    {
      int count = 0;
      XmlNodeList smilrefNodes = instanceDoc.SelectNodes("//Node/mChildren[@smilref]");
      foreach (XmlNode nod in smilrefNodes)
      {
        count++;
        XmlElement mChildren = (XmlElement)nod;
        FireProgress(String.Format(
          "Handling smilref {0} ({1:0}/{2:0})", 
          mChildren.GetAttribute("smilref"), count, smilrefNodes.Count));
        XmlNode temp = mChildren.SelectSingleNode("mMediaObject");
        XmlElement[] AudioObjects = XmlNodeListToXmlElementArray(
          mChildren.SelectNodes("mMediaObject//AudioObject"));
        mChildren.RemoveChild(temp);
        XmlElement[] Nodes = XmlNodeListToXmlElementArray(mChildren.SelectNodes("Node"));
        int aoIndex = 0;
        int nIndex = 0;
        while (nIndex<Nodes.Length && aoIndex<AudioObjects.Length)
        {
          if (Nodes[nIndex].SelectNodes(".//AudioObject").Count>0)
          {
            //Advance auIndex to point at the first AudioObject 
            //after the ones used by Nodes[nIndex] and descendants
            while (aoIndex<AudioObjects.Length)
            {
              bool used = false;
              foreach (XmlNode idAttr in Nodes[nIndex].SelectNodes(".//AudioObject/@id"))
              {
                if (AudioObjects[aoIndex].GetAttribute("id")==idAttr.InnerText)
                {
                  used = true;
                  break;
                }
              }
              if (!used) break;
              aoIndex++;
            }
            nIndex++;
          }
          else
          {
            int nSubIndex = nIndex;
            XmlElement nextDescendantAO = null;
            //advance nSubIndex to pount at the next Node with a descendant AudioObject
            while (nSubIndex<Nodes.Length)
            {
              XmlNodeList naoNodes = Nodes[nSubIndex].SelectNodes(".//AudioObject");
              if (naoNodes.Count>0) 
              {
                nextDescendantAO = (XmlElement)naoNodes[0];
                break;
              }
              nSubIndex++;
            }
            //The recipient Node for AudioObjects. 
            //Can be an existing child of mChildren or an inserted wrapper Node
            XmlElement recipientNode;
            if (nSubIndex==(nIndex+1))
            {
              //Only a single Node, no need to wrap
              recipientNode = Nodes[nIndex];
            }
            else
            {
              //Wrap Nodes[nIndex]-Nodes[nSubIndex] in an new created recipientNode
              recipientNode = instanceDoc.CreateElement("Node");
              recipientNode.AppendChild(instanceDoc.CreateElement("mProperties")).AppendChild(
                instanceDoc.CreateElement("ChannelsProperty")).AppendChild(
                instanceDoc.CreateElement("mMediaObjects"));
              XmlNode nodMChildren = recipientNode.AppendChild(instanceDoc.CreateElement("mChildren"));
              mChildren.InsertBefore(recipientNode, Nodes[nIndex]);
              for (int i=nIndex; i<nSubIndex; i++)
              {
                nodMChildren.AppendChild(mChildren.RemoveChild(Nodes[i]));
              }
            }
            //Create mMediaObject descendant of recipientNode element for the audioChannel
            XmlElement mMediaObjectForAudio = (XmlElement)recipientNode.SelectSingleNode(
              "mProperties/ChannelsProperty/mMediaObjects").AppendChild(instanceDoc.CreateElement("mMediaObject"));
            mMediaObjectForAudio.SetAttribute("for", "audioChannel");
            nIndex = nSubIndex;
            int aoSubIndex = aoIndex;
            //Advance aoSubIndex to point immeadtly after the last AudioObject to add to recipientNode
            if (nextDescendantAO==null) aoSubIndex=AudioObjects.Length;
            while (aoSubIndex<AudioObjects.Length)
            {
              if (AudioObjects[aoSubIndex].GetAttribute("id")==nextDescendantAO.GetAttribute("id"))
              {
                break;
              }
              aoSubIndex++;
            }
            if (aoSubIndex==(aoIndex+1))
            {
              mMediaObjectForAudio.AppendChild(AudioObjects[aoIndex]);
            }
            else
            {
              XmlElement MediaSequence = instanceDoc.CreateElement("MediaSequence");
              for (int i=aoIndex; i<aoSubIndex; i++)
              {
                MediaSequence.AppendChild(AudioObjects[i]);
              }
              mMediaObjectForAudio.AppendChild(MediaSequence);
            }
            aoIndex = aoSubIndex;
          }
        }
      }
    }


    /// <summary>
    /// Generates the instance xml document
    /// </summary>
    /// <returns>The instance <see cref="XmlDocument"/></returns>
    public XmlDocument GenerateInstanceXml(bool ProcessNestedSmilrefs)
    {
      if (!System.IO.File.Exists(DTBOOKPath))
      {
        throw new ApplicationException(String.Format(
          "Could not find input dtbook file {0}", DTBOOKPath));
      }
      XslTransform trans = new XslTransform(XSLT_PATH, DTBOOKPath);
      XmlDocument instanceDoc = new XmlDocument();
      //string dtbookDir = System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(DTBOOKPath));
      instanceDoc.LoadXml(trans.Transform());
      FireProgress("Generated instance document");
      if (ProcessNestedSmilrefs)
      {
        ProcessNestedSmilrefNodes(instanceDoc);
        FireProgress("Processed nested smilrefs in instance document");
      }
      return instanceDoc;
    }
  }
}
