function ToggleExpanded(aId)
{
	var aElem = document.getElementById(aId);
	var aaElem = document.getElementById("a"+aId);
	var ulElem = document.getElementById("ul"+aId);
	if (ulElem.style.display=="")
	{
		ulElem.style.display = "none";
		aElem.innerText = "+";
		aElem.title = "Expand "+aaElem.innerText;
	}
	else
	{
		ulElem.style.display = "";
		aElem.innerText = "-";
		aElem.title = "Collapse "+aaElem.innerText;
	}
}